"""Discord presentation layer only."""
